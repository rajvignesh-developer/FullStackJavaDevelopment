module companyLockersPhase1Project {
}